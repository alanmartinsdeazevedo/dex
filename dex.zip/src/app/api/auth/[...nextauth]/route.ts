import { handlers } from "@/src/app/api/auth/[...nextauth]/auth"
export const { GET, POST } = handlers