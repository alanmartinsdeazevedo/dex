const API = process.env.NEXT_PUBLIC_API_KEY;

export const authAPI = async () => {
  const tokenAPI = API;
  return tokenAPI;
  
}